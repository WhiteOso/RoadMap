﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            masterGridView1 = new MasterGridView(this);
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            masterGridView1.DataSource = Persona.getPersonas();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //masterGridView1.Rows[e.RowIndex].DividerHeight = this.Rows[e.RowIndex].Height - rowDefaultHeight_22;
            //e.Graphics.DrawImage(rowHeaderIconList.Images[(int)rowHeaderIcons.collapse], rect);
            //detailTabControl.Location = new Point(e.RowBounds.Left + this.RowHeadersWidth, e.RowBounds.Top + rowDefaultHeight_22 + 5);
            //detailTabControl.Width = e.RowBounds.Right - this.RowHeadersWidth;
            //detailTabControl.Height = this.Rows[e.RowIndex].DividerHeight - 10;
            //detailTabControl.Visible = true;
        }
    }
}
