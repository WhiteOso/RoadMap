﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public class DetailTabControl : TabControl
    {
        public DetailTabControl()
        {
            
        }

       
        internal void AddChildgrid(IList listOfDetail, string name)
        {
            TabPage tabpage = new TabPage { Text = name };

            this.TabPages.Add(tabpage);

            DataGridView grid = new DataGridView();
            // Poner un contador en el rowheader
            //grid.RowPostPaint += cModule.rowPostPaint_HeaderCount;
            
            grid.Dock = DockStyle.Fill;
            grid.MultiSelect = true;
            grid.ReadOnly = false;
            grid.AllowUserToAddRows = true;
            grid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            grid.AllowUserToResizeRows = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            grid.AutoGenerateColumns = false;
            grid.Columns.Clear();
            grid.AutoGenerateColumns = true;
            DataGridViewColumnCollection columns = grid.Columns;

            

            cModule.applyGridTheme(grid);
            cModule.setGridRowHeader(grid);

            // Agregar la data
            BindingSource bs = new BindingSource();
            bs.DataSource = listOfDetail;
            bs.AllowNew = true;
            grid.DataSource = bs;

            cModule.setGridColumnStyleAfterBinding(grid);

            tabpage.Controls.Add(grid);
        }


    }
}
