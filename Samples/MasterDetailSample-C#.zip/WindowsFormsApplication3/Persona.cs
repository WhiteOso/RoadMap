﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    public class Persona
    {

        public int Id { get; set; }
        public string Nombre { get; set; }

        public string Apellido { get; set; }

        public Persona(int id, string nombre, string apellido) 
        {
            Nombre = nombre;
            Apellido = apellido;
            Id = id;
        }

        public Persona() { }

        public static List<Persona> getPersonas()
        {
            List<Persona> list = new List<Persona>();
            list.Add(new Persona(1, "Periodo", "Palotes"));
            list.Add(new Persona(2, "John", "Doe"));
            list.Add(new Persona(3, "Juan", "Perez"));

            return list;
        }
    }
}
