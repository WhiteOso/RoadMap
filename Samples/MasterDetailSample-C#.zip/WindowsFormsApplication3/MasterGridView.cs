﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public class MasterGridView : DataGridView
    {
        internal List<int> lstCurrentRows = new List<int>();
        internal const int rowDefaultHeight_22 = 22;
        internal const int rowExpandedHeight_300 = 300;
        internal int rowDefaultDivider_0 = 0;
        internal const int rowExpandedDivider_278 = rowExpandedHeight_300 - rowDefaultHeight_22;
        internal const int rowDividerMargin_5 = 5;
        internal bool doCollapseRow = false;


        ImageList rowHeaderIconList = new ImageList();

        internal DetailTabControl detailTabControl = new DetailTabControl
        {
            Height = rowExpandedDivider_278 - rowDividerMargin_5 * 2,
            Visible = false
        };

        private System.ComponentModel.IContainer components;

        public enum rowHeaderIcons
        {
            expand = 1,
            collapse = 0
        }

        public Control parent = null;

        public MasterGridView(Control m_parent)
        {
            InitializeComponent();

            parent = m_parent;

            rowHeaderIconList.Images.Add(Datos.expanded);
            rowHeaderIconList.Images.Add(Datos.collapsed);
            rowHeaderIconList.TransparentColor = System.Drawing.Color.Transparent;
            rowHeaderIconList.Images.SetKeyName(1, "expanded.gif");
            rowHeaderIconList.Images.SetKeyName(0, "collapsed.gif");

            EnableHeadersVisualStyles = false;
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            ColumnHeadersHeight = 105;

            //Scroll += MasterControl_Scroll;

            RowPostPaint += MasterControl_RowPostPaint;

            // Al dar click en el símbolo "+" del rowheader
            RowHeaderMouseClick += MasterControl_RowHeaderMouseClick;

            
            parent.Controls.Add(detailTabControl);
            detailTabControl.BringToFront();


            cModule.applyGridTheme(this);
            cModule.setGridRowHeader(this);

            Dock = DockStyle.Fill;


        }



        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MasterGridView));


            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();

            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
        }



        int counter = 0;
        private void MasterControl_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            Console.WriteLine("MasterControl_RowPostPaint: " + counter++);
            Rectangle rect = new Rectangle(e.RowBounds.X + ((rowDefaultHeight_22 - 16) / 2), e.RowBounds.Y + ((rowDefaultHeight_22 - 16) / 2), 16, 16);
            
            if (doCollapseRow)
            {
                if (lstCurrentRows.Contains(e.RowIndex))
                {
                    this.Rows[e.RowIndex].DividerHeight = this.Rows[e.RowIndex].Height - rowDefaultHeight_22;
                    e.Graphics.DrawImage(rowHeaderIconList.Images[(int)rowHeaderIcons.collapse], rect);
                    detailTabControl.Location = new Point(e.RowBounds.Left + this.RowHeadersWidth, e.RowBounds.Top + rowDefaultHeight_22 + 5);
                    detailTabControl.Width = e.RowBounds.Right - this.RowHeadersWidth;
                    detailTabControl.Height = this.Rows[e.RowIndex].DividerHeight - 10;
                    detailTabControl.Visible = true;
                    //detailTabControl.Focus();
                }
                else
                {
                    detailTabControl.Visible = false;
                    e.Graphics.DrawImage(rowHeaderIconList.Images[(int)rowHeaderIcons.expand], rect);
                }
                doCollapseRow = false;
            }
            else
            {
                if (lstCurrentRows.Contains(e.RowIndex))
                {
                    this.Rows[e.RowIndex].DividerHeight = this.Rows[e.RowIndex].Height - rowDefaultHeight_22;
                    e.Graphics.DrawImage(rowHeaderIconList.Images[(int)rowHeaderIcons.collapse], rect);
                    detailTabControl.Location = new Point(e.RowBounds.Left + this.RowHeadersWidth, e.RowBounds.Top + rowDefaultHeight_22 + 5);
                    detailTabControl.Width = e.RowBounds.Right - this.RowHeadersWidth;
                    detailTabControl.Height = this.Rows[e.RowIndex].DividerHeight - 10;
                    detailTabControl.Visible = true;
                    //detailTabControl.Focus();
                }
                else
                {
                    e.Graphics.DrawImage(rowHeaderIconList.Images[(int)rowHeaderIcons.expand], rect);
                }
            }

            //cModule.rowPostPaint_HeaderCount(sender, e);
        }

        private void MasterControl_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //List<Nota> list = Nota.getNotas();
            //detailTabControl.AddChildgrid(list, "Notas");
            //this.Rows[0].Height = rowExpandedHeight;
            //this.Rows[0].DividerHeight = rowExpandedDivider;

            Rectangle rect = new Rectangle((rowDefaultHeight_22 - 16) / 2, (rowDefaultHeight_22 - 16) / 2, 16, 16);
            if (rect.Contains(e.Location))
            {
                int rowIndex = e.RowIndex;

                if (lstCurrentRows.Contains(rowIndex))
                {
                    lstCurrentRows.Clear();
                    this.Rows[rowIndex].Height = rowDefaultHeight_22;
                    this.Rows[rowIndex].DividerHeight = rowDefaultDivider_0;
                }
                else
                {
                    if (lstCurrentRows.Count != 0)
                    {
                        int eRow = lstCurrentRows[0];
                        lstCurrentRows.Clear();
                        this.Rows[eRow].Height = rowDefaultHeight_22;
                        this.Rows[eRow].DividerHeight = rowDefaultDivider_0;
                        this.ClearSelection();
                        doCollapseRow = true;
                        this.Rows[eRow].Selected = true;
                    }

                    lstCurrentRows.Add(rowIndex);

                    Persona rowParentSelected = (Persona)(this.Rows[rowIndex].DataBoundItem);

                    // Detalle
                    detailTabControl.TabPages.Clear();

                    if (rowParentSelected != null)
                    {
                        List<Nota> list = Nota.getNotas();
                        detailTabControl.AddChildgrid(list, "Notas");
                    }

                    // expandir la fila
                    if (detailTabControl.HasChildren)
                    {
                        this.Rows[rowIndex].Height = rowExpandedHeight_300;
                        this.Rows[rowIndex].DividerHeight = rowExpandedDivider_278;
                    }
                    else
                    {
                        detailTabControl.Visible = false;
                    }
                }
                this.ClearSelection();
                doCollapseRow = true;
                this.Rows[rowIndex].Selected = true;

            }
            else
            {
                doCollapseRow = false;
            }
        }

      


        //private void MasterControl_Scroll(object sender, ScrollEventArgs e)
        //{
        //    if (!(lstCurrentRows.Count == 0))
        //    {
        //        collapseRow = true;
        //        this.ClearSelection();
        //        this.Rows[lstCurrentRows[0]].Selected = true;
        //    }
        //}
    }
}
