﻿Public Class frmMain
    'Developed by: Gani Weecom
    'Email:ganiweecom@yahoo.com
    Dim masterDetail As MasterControl
    Sub clearFields()
        panelView.Controls.Clear()
        masterDetail = Nothing
        Refresh()
    End Sub
    Sub loadData()
        clearFields()
        Me.OrderReportsTableAdapter.Fill(Me.NwindDataSet.OrderReports)
        Me.InvoicesTableAdapter.Fill(Me.NwindDataSet.Invoices)
        Me.CustomersTableAdapter.Fill(Me.NwindDataSet.Customers)
        createMasterDetailView()
    End Sub
    Sub createMasterDetailView()
        masterDetail = New MasterControl(NwindDataSet)
        panelView.Controls.Add(masterDetail)
        masterDetail.setParentSource(NwindDataSet.Customers.TableName, "CustomerID")
        masterDetail.childView.Add(NwindDataSet.OrderReports.TableName, "Orders")
        masterDetail.childView.Add(NwindDataSet.Invoices.TableName, "Invoices")
    End Sub
    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        loadData()
    End Sub
End Class
